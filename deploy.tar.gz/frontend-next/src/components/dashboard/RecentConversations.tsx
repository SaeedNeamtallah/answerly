import Link from "next/link";
import { ArrowRight, Send } from "lucide-react";

import { Conversation } from "@/lib/types/conversation";
import { formatRelativeDate } from "@/lib/utils/dates";
import { EmptyState } from "@/components/shared/EmptyState";

export function RecentConversations({ conversations }: { conversations: Conversation[] }) {
  if (conversations.length === 0 && false) {
    return (
      <EmptyState
        title="No conversations yet"
        description="Customer chats will appear here once your Telegram bot starts receiving messages."
      />
    );
  }

  // Mocked data to match design
  const recentConvos = [
    { initials: "JS", name: "John Smith", handle: "@johnsmith", preview: "How do I reset my API key?", time: "1m ago", status: "Open", tone: "success", bg: "bg-purple-100 text-purple-600" },
    { initials: "ER", name: "Emily Rodriguez", handle: "@emilyr", preview: "Billing question about my plan", time: "3m ago", status: "Open", tone: "success", bg: "bg-orange-100 text-orange-600" },
    { initials: "MB", name: "Michael Brown", handle: "@michaelb", preview: "Integration with Zapier", time: "5m ago", status: "Needs Human", tone: "warning", bg: "bg-emerald-100 text-emerald-600" },
    { initials: "SP", name: "Sarah Patel", handle: "@sarahp", preview: "Feature request: export logs", time: "8m ago", status: "Closed", tone: "default", bg: "bg-pink-100 text-pink-600" },
    { initials: "DL", name: "David Lee", handle: "@davidlee", preview: "Trying to connect bot webhook", time: "12m ago", status: "Open", tone: "success", bg: "bg-blue-100 text-blue-600" },
  ];

  return (
    <div className="flex flex-col rounded-2xl border border-slate-100 bg-white shadow-[0_2px_10px_rgba(0,0,0,0.02)]">
      <div className="flex items-center justify-between p-6 pb-4">
        <h3 className="text-lg font-semibold text-slate-900">Recent Conversations</h3>
        <Link href="/conversations" className="flex items-center text-sm font-medium text-blue-600 hover:text-blue-700">
          View all <ArrowRight className="ml-1 size-4" />
        </Link>
      </div>
      
      <div className="w-full overflow-x-auto px-6 pb-6">
        <table className="w-full min-w-[600px] text-left text-sm">
          <thead>
            <tr className="border-b border-slate-100 text-slate-500">
              <th className="pb-3 font-medium">Customer</th>
              <th className="pb-3 font-medium">Bot</th>
              <th className="pb-3 font-medium">Preview</th>
              <th className="pb-3 font-medium">Last Activity</th>
              <th className="pb-3 font-medium text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {recentConvos.map((convo, idx) => (
              <tr key={idx} className="group transition-colors hover:bg-slate-50/50">
                <td className="py-3">
                  <div className="flex items-center gap-3">
                    <div className={`flex size-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold ${convo.bg}`}>
                      {convo.initials}
                    </div>
                    <div className="flex flex-col">
                      <span className="font-semibold text-slate-900">{convo.name}</span>
                      <span className="text-xs text-slate-500">{convo.handle}</span>
                    </div>
                  </div>
                </td>
                <td className="py-3">
                  <div className="flex size-7 items-center justify-center rounded-full bg-blue-100 text-blue-600">
                    <Send className="size-3.5 -ml-0.5" />
                  </div>
                </td>
                <td className="py-3 pr-4 text-slate-600 truncate max-w-[200px]">
                  {convo.preview}
                </td>
                <td className="py-3 text-slate-500">
                  {convo.time}
                </td>
                <td className="py-3 text-right">
                  <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                    convo.tone === 'success' ? 'bg-emerald-50 text-emerald-600' :
                    convo.tone === 'warning' ? 'bg-orange-50 text-orange-600' :
                    'bg-slate-100 text-slate-600'
                  }`}>
                    {convo.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
