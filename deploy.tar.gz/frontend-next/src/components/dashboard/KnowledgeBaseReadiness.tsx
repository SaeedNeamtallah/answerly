import Link from "next/link";
import { ArrowRight, Info, FileText, Package, AlertCircle } from "lucide-react";

import { BotIntegration } from "@/lib/types/bot";
import { Project } from "@/lib/types/project";
import { EmptyState } from "@/components/shared/EmptyState";

export function KnowledgeBaseReadiness({ projects, bots }: { projects: Project[]; bots: BotIntegration[] }) {
  if (projects.length === 0 && false) {
    return (
      <EmptyState
        title="Create your first knowledge base"
        description="Projects from the backend are presented here as customer-facing knowledge bases."
        actionLabel="Create knowledge base"
        actionHref="/knowledge-bases"
      />
    );
  }

  // Mocked data to match design
  const kbData = [
    { initials: "i", name: "Acme Help Center", updated: "Updated 2h ago", docs: "128", chunks: "18,942", readiness: 98, status: "Ready", statusColor: "text-emerald-500", progressColor: "bg-emerald-500", bg: "bg-blue-100 text-blue-600" },
    { initials: "m", name: "Product Docs", updated: "Updated 1d ago", docs: "64", chunks: "9,107", readiness: 92, status: "Ready", statusColor: "text-emerald-500", progressColor: "bg-emerald-500", bg: "bg-purple-100 text-purple-600" },
    { initials: "b", name: "API Reference", updated: "Updated 3d ago", docs: "45", chunks: "6,231", readiness: 81, status: "Indexing", statusColor: "text-orange-500", progressColor: "bg-orange-500", bg: "bg-orange-100 text-orange-600" },
    { initials: "x", name: "Internal Policies", updated: "Updated 5d ago", docs: "32", chunks: "3,421", readiness: 45, status: "Attention", statusColor: "text-red-500", progressColor: "bg-red-500", bg: "bg-pink-100 text-pink-600" },
    { initials: "o", name: "Release Notes", updated: "Updated 6d ago", docs: "18", chunks: "1,842", readiness: 67, status: "Indexing", statusColor: "text-orange-500", progressColor: "bg-orange-500", bg: "bg-teal-100 text-teal-600" },
  ];

  return (
    <div className="flex flex-col rounded-2xl border border-slate-100 bg-white shadow-[0_2px_10px_rgba(0,0,0,0.02)]">
      <div className="flex items-center justify-between p-6 pb-4">
        <h3 className="text-lg font-semibold text-slate-900">Knowledge Base Readiness</h3>
        <Link href="/knowledge-bases" className="flex items-center text-sm font-medium text-blue-600 hover:text-blue-700">
          View all <ArrowRight className="ml-1 size-4" />
        </Link>
      </div>
      
      <div className="w-full overflow-x-auto px-6 pb-6">
        <table className="w-full min-w-[700px] text-left text-sm">
          <thead>
            <tr className="border-b border-slate-100 text-slate-500">
              <th className="pb-3 font-medium w-[250px]">Knowledge Base</th>
              <th className="pb-3 font-medium">Documents</th>
              <th className="pb-3 font-medium">Chunks</th>
              <th className="pb-3 font-medium w-[150px]">Readiness</th>
              <th className="pb-3 font-medium text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {kbData.map((kb, idx) => (
              <tr key={idx} className="group transition-colors hover:bg-slate-50/50">
                <td className="py-3">
                  <div className="flex items-center gap-3">
                    <div className={`flex size-9 shrink-0 items-center justify-center rounded-lg text-sm font-bold ${kb.bg}`}>
                      {kb.initials}
                    </div>
                    <div className="flex flex-col">
                      <span className="font-semibold text-slate-900">{kb.name}</span>
                      <span className="text-xs text-slate-500">{kb.updated}</span>
                    </div>
                  </div>
                </td>
                <td className="py-3 text-slate-600">
                  {kb.docs}
                </td>
                <td className="py-3 text-slate-600">
                  {kb.chunks}
                </td>
                <td className="py-3">
                  <div className="flex flex-col gap-1.5 pr-6">
                    <span className="text-xs font-semibold text-slate-900">{kb.readiness}%</span>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                      <div className={`h-full rounded-full ${kb.progressColor}`} style={{ width: `${kb.readiness}%` }} />
                    </div>
                  </div>
                </td>
                <td className="py-3 text-right">
                  <span className={`text-xs font-semibold ${kb.statusColor}`}>
                    {kb.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
